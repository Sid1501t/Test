$(document).ready(function(x) {
  x.preventDefault();
})
